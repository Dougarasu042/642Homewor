<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>CodePen - Registration Form (Bootstrap 5 Validation)</title>
  <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css'><link rel="stylesheet" href="./style.css">

</head>
<body>
<!-- partial:index.partial.html -->



<div class="form-body">
        Hello <?php echo $_POST["Lastname"]; ?>!<br>
 Your mail is <?php echo $_POST["FirstName"]; ?>. 
    </div>
<!-- partial -->

</body>
</html>


